# AIAAS Tutorial — Talk to Qwen Models (No Coding Needed)

This folder lets you use two UBS-hosted Qwen AI models from your computer:

| Script | What it does |
|---|---|
| `qwen_chat.py` | Chat with **Qwen3.6-27B** (ask questions, get answers) |
| `qwen_embedding.py` | Turn text into number-vectors with **Qwen3-Embedding-8B** (used for search/similarity) |

## Step 1 — One-time setup (≈2 minutes)

Open **Terminal**, go to this folder, and run:

```bash
bash setup.sh
```

This creates a Python 3.14 environment called `aiaas` and installs everything
(`aiaas-auth`, `openai`, `httpx`).


## Step 2 — Every time you want to use it

```bash
conda activate aiaas
```

Then pick one:

```bash
python qwen_chat.py        # chat with the model
python qwen_embedding.py   # create text embeddings
```

- The first time, a **browser window may open for login** — just sign in as usual.
- Type your question/text and press **Enter**.
- Type **`quit`** to stop.

## Notes

- If anything breaks, delete the environment and re-run setup:

  ```bash
  conda remove -n aiaas --all -y
  bash setup.sh
  ```

- Technical details live in the two handover documents:
  - `qwen3_6_27b_coding_agent_integration.md`
  - `Qwen3_Embedding_8B_Handover.md`
