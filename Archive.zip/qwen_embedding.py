"""
============================================================
 Qwen Embeddings - Turn text into numbers (vectors)
------------------------------------------------------------
 For non-coders:
   1. Make sure you ran:  bash setup.sh   (one time only)
   2. Activate the environment:  conda activate aiaas
   3. Run this script:  python qwen_embedding.py
   4. Type (or paste) some text, press Enter.
      The script prints the "embedding" - a list of numbers
      that represents the meaning of your text. These are
      used for search, recommendations, and similarity.
   5. Type 'quit' to exit.
============================================================
"""

import sys
import httpx
from openai import OpenAI
from aiaas_auth import AuthMode, AzureAuthClient

# ---- Settings (from the AIaaS handover document - do not change) ----
BROKER_URL = "https://aiaas-broker.uk8s-tsshared-weu-gt021-ext-p001.azpriv-cloud.ubs.net/"
GATEWAY_BASE_URL = "https://gateway.aimart-apim-prod.azpriv-cloud.ubs.net/aiaas/v1"
MODEL_ID = "Qwen/Qwen3-Embedding-8B"


def connect():
    """Log in through the company broker and create the model client."""
    print("Connecting and logging in (a browser window may open)...")
    auth = AzureAuthClient(
        broker_url=BROKER_URL,
        mode=AuthMode.DEVPOD,
        auto_refresh=True,
    )
    token = auth.authenticate_broker().access_token
    client = OpenAI(
        base_url=GATEWAY_BASE_URL,
        api_key=token,
        http_client=httpx.Client(verify=False),  # required on the internal network
        timeout=60,
    )
    print("Connected! ✅\n")
    return client


def main():
    client = connect()

    print("=" * 55)
    print("  Text Embeddings with Qwen3-Embedding-8B")
    print("  Type or paste text, press Enter.")
    print("  Type 'quit' or 'exit' to stop.")
    print("=" * 55)

    while True:
        try:
            text = input("\nYour text: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            break

        if not text:
            continue
        if text.lower() in ("quit", "exit"):
            print("Goodbye!")
            break

        try:
            response = client.embeddings.create(model=MODEL_ID, input=text)
        except Exception as error:
            print(f"\n⚠️  Something went wrong: {error}")
            print("Try again with different text.")
            continue

        vector = response.data[0].embedding

        print(f"\n✅ Embedding created!")
        print(f"   Vector length (dimensions): {len(vector)}")
        print(f"   First 10 numbers: {[round(v, 4) for v in vector[:10]]}")
        if response.usage:
            print(f"   Tokens used: {response.usage.total_tokens}")


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(f"\nCould not start: {error}")
        print("If this is your first time, make sure you ran: bash setup.sh")
        sys.exit(1)
