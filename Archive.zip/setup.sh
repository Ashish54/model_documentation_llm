#!/bin/bash
# ============================================================
#  AIAAS Tutorial - One-Time Setup
# ------------------------------------------------------------
#  WHAT THIS DOES (no coding knowledge needed):
#    1. Creates a Python environment called "aiaas" (Python 3.14)
#    2. Installs everything needed to talk to the Qwen models
#
#  HOW TO RUN:
#    Open Terminal, go to this folder, then type:
#        bash setup.sh
# ============================================================

set -e  # stop immediately if something fails

ENV_NAME="aiaas"
PYTHON_VERSION="3.14"

echo "=================================================="
echo "  AIAAS Tutorial - Setting up your environment"
echo "=================================================="

# ---- Step 0: Check conda is installed ----------------------
if ! command -v conda &> /dev/null; then
    echo ""
    echo "ERROR: 'conda' was not found on this computer."
    echo "Please install Miniconda first:"
    echo "  https://docs.conda.io/en/latest/miniconda.html"
    echo "Then run this script again."
    exit 1
fi

# Make conda work inside this script
source "$(conda info --base)/etc/profile.d/conda.sh"

# ---- Step 1: Create the environment ------------------------
if conda env list | grep -q "^${ENV_NAME} "; then
    echo ""
    echo "Environment '${ENV_NAME}' already exists - skipping creation."
else
    echo ""
    echo "[1/2] Creating Python ${PYTHON_VERSION} environment named '${ENV_NAME}'..."
    conda create -y -n "${ENV_NAME}" python="${PYTHON_VERSION}"
fi

# ---- Step 2: Install dependencies --------------------------
echo ""
echo "[2/2] Installing required packages (aiaas-auth, openai, httpx)..."
conda activate "${ENV_NAME}"
pip install --upgrade pip
pip install aiaas-auth openai httpx

echo ""
echo "=================================================="
echo "  Setup complete! 🎉"
echo ""
echo "  To use the scripts, first activate the environment:"
echo "      conda activate ${ENV_NAME}"
echo ""
echo "  Then run either:"
echo "      python qwen_chat.py        <- chat with Qwen3.6-27B"
echo "      python qwen_embedding.py   <- create text embeddings"
echo "=================================================="
