"""
============================================================
 Qwen Chat - Talk to the Qwen3.6-27B model
------------------------------------------------------------
 For non-coders:
   1. Make sure you ran:  bash setup.sh   (one time only)
   2. Activate the environment:  conda activate aiaas
   3. Run this script:  python qwen_chat.py
   4. Type your question, press Enter. Type 'quit' to exit.
============================================================
"""

import sys
import httpx
from openai import OpenAI
from aiaas_auth import AuthMode, AzureAuthClient

# ---- Settings (from the AIMart model catalog - do not change) ----
BROKER_URL = "https://aiaas-broker.uk8s-tsshared-weu-gt021-ext-p001.azpriv-cloud.ubs.net/"
GATEWAY_BASE_URL = "https://gateway.aimart-apim-prod.azpriv-cloud.ubs.net/aiaas/v1"
MODEL_ID = "Qwen/Qwen3.6-27B"
MAX_OUTPUT_TOKENS = 2000  # model supports up to 8K output tokens


def connect():
    """Log in through the company broker and create the model client."""
    print("Connecting and logging in (a browser window may open)...")
    auth = AzureAuthClient(
        broker_url=BROKER_URL,
        mode=AuthMode.DEVPOD,
        auto_refresh=True,
    )
    token = auth.authenticate_broker().access_token
    client = OpenAI(
        base_url=GATEWAY_BASE_URL,
        api_key=token,
        http_client=httpx.Client(verify=False),  # required on the internal network
        timeout=60,
    )
    print("Connected! ✅\n")
    return client


def main():
    client = connect()

    # The conversation history - this gives the model "memory" of the chat
    messages = [
        {"role": "system", "content": "You are a helpful, friendly assistant. "
                                      "Answer clearly and concisely."}
    ]

    print("=" * 55)
    print("  Chat with Qwen3.6-27B")
    print("  Type your message and press Enter.")
    print("  Type 'quit' or 'exit' to stop.")
    print("=" * 55)

    while True:
        try:
            user_text = input("\nYou: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            break

        if not user_text:
            continue
        if user_text.lower() in ("quit", "exit"):
            print("Goodbye!")
            break

        messages.append({"role": "user", "content": user_text})

        try:
            response = client.chat.completions.create(
                model=MODEL_ID,
                messages=messages,
                max_tokens=MAX_OUTPUT_TOKENS,
            )
        except Exception as error:
            print(f"\n⚠️  Something went wrong: {error}")
            print("Your previous messages are still saved - try again.")
            messages.pop()  # remove the failed question
            continue

        answer = response.choices[0].message.content
        messages.append({"role": "assistant", "content": answer})

        print(f"\nQwen: {answer}")
        if response.usage:
            print(f"(tokens used: {response.usage.total_tokens})")


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(f"\nCould not start: {error}")
        print("If this is your first time, make sure you ran: bash setup.sh")
        sys.exit(1)
